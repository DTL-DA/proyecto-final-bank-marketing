"""Punto de entrada local: python app.py"""

from src.app import app, main, server  # noqa: F401

if __name__ == "__main__":
    main()
