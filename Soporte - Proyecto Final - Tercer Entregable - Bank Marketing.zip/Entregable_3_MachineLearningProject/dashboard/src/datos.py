"""Carga de los resultados que exporta el cuaderno (carpeta ``datos/``)."""

import json
from functools import lru_cache
from pathlib import Path

import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
DATOS = RAIZ / "datos"


@lru_cache(maxsize=None)
def tabla(nombre: str) -> pd.DataFrame:
    """Lee ``datos/<nombre>.parquet``."""
    return pd.read_parquet(DATOS / f"{nombre}.parquet")


@lru_cache(maxsize=None)
def objeto(nombre: str) -> dict:
    """Lee ``datos/<nombre>.json``."""
    return json.loads((DATOS / f"{nombre}.json").read_text(encoding="utf-8"))


def num(x, d=0) -> str:
    """Número con coma decimal y espacio de miles."""
    return f"{x:,.{d}f}".replace(",", " ").replace(".", ",")


def pct(x, d=1) -> str:
    return f"{num(100 * x, d)} %"


def pval(p) -> str:
    return "< 0,001" if p < 0.001 else num(p, 3)


def p_txt(p) -> str:
    return "p < 0,001" if p < 0.001 else f"p = {num(p, 3)}"


def enumerar(items) -> str:
    items = [str(i) for i in items]
    if not items:
        return ""
    return items[0] if len(items) == 1 else ", ".join(items[:-1]) + " y " + items[-1]
