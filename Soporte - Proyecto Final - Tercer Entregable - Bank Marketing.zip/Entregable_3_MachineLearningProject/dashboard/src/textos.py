"""Interpretaciones de cada resultado del dashboard, calculadas con las mismas cifras que muestran las figuras.

Cada función devuelve tres párrafos: lo que muestra el resultado, lo que significa y la decisión que se toma.
"""

import numpy as np

from .datos import enumerar, num, objeto, p_txt, pct, tabla


def contexto():
    c = objeto("contexto")
    return [
        f"**Interpretación.** Tras eliminar duplicados quedan {num(c['registros_limpios'])} llamadas: "
        f"{num(c['n_tr'])} de entrenamiento ({c['desde_tr']} a {c['hasta_tr']}) y {num(c['n_te'])} de prueba "
        f"({c['desde_te']} a {c['hasta_te']}). Suscribe el {pct(c['prev_tr'])} en entrenamiento y el "
        f"{pct(c['prev_te'])} en prueba. Se evaluaron {c['combinaciones']} combinaciones en {c['k_ext']} pliegues "
        f"externos, con {num(c['evaluaciones'])} evaluaciones internas, {num(c['ajustes'])} ajustes y "
        f"{num(c['horas_cpu'], 1)} horas de CPU.",
        "Esto significa que el modelo se juzga como se usaría: entrenado con el pasado y evaluado en campañas "
        "posteriores, donde la tasa de suscripción es casi cinco veces mayor. Ese cambio de prevalencia es tan "
        "importante como el desbalance de clases.",
        "Por tal motivo, se opta por una validación anidada cronológica, por el AUC-PR como criterio principal y por "
        "analizar por separado el balanceo (que actúa sobre el umbral) y la recalibración mensual (que sigue el "
        "cambio de régimen).",
    ]


def por_pliegue():
    a = tabla("auc_por_pliegue").set_index("Modelo")
    ult = a.columns[-1]
    return [
        f"**Interpretación.** En los cuatro pliegues que validan dentro de 2008, el mejor AUC de cada modelo va de "
        f"{num(a.iloc[:, :-1].min().min(), 3)} a {num(a.iloc[:, :-1].max().max(), 3)}; en el último ({ult}) va de "
        f"{num(a[ult].min(), 3)} ({a[ult].idxmin()}) a {num(a[ult].max(), 3)} ({a[ult].idxmax()}).",
        "Esto significa que dentro de 2008 ningún modelo ordena a los clientes mejor que el azar con información previa "
        "a la llamada; la señal aparece al validar en 2009, cuando cambia el régimen económico, y ahí los modelos más "
        "simples extrapolan igual o mejor que los flexibles.",
        "Por tanto, corresponde leer el promedio de los cinco pliegues como una estimación conservadora, que en la "
        "práctica ordena las combinaciones según el último pliegue, y contrastarla con el conjunto de prueba.",
    ]


def mapa_balanceo():
    m = tabla("mapa_balanceo").set_index("modelo")
    mejor = m.max(axis=1)
    rango = (m.max(axis=1) - m.min(axis=1))
    return [
        f"**Interpretación.** El mejor AUC-PR externo por modelo va de {num(mejor.min(), 3)} ({mejor.idxmin()}) a "
        f"{num(mejor.max(), 3)} ({mejor.idxmax()}), una diferencia de {num(mejor.max() - mejor.min(), 3)}; dentro de un "
        f"mismo modelo, el rango entre técnicas de balanceo va de {num(rango.min(), 3)} a {num(rango.max(), 3)}.",
        ("Lo anterior indica que la elección del modelo pesa más que la del balanceo en una métrica de orden: "
         "balancear no enseña al modelo a ordenar mejor a los clientes." if mejor.max() - mejor.min() > rango.median()
         else "Lo anterior indica que, en una métrica de orden, las diferencias entre modelos y entre técnicas de "
              "balanceo son del mismo tamaño y pequeñas frente a la variación entre periodos."),
        "Por ello, se recomienda elegir el modelo por su capacidad de discriminación en prueba y decidir el balanceo "
        "por el punto de operación que necesita la campaña.",
    ]


def balanceo():
    b = tabla("balanceo_modelo").groupby("Balanceo")[["recall", "f1", "auc_pr", "brier"]].mean()
    return [
        f"**Interpretación.** En promedio, el recall con el umbral por defecto es {num(b.loc['Sin balanceo', 'recall'], 3)} "
        f"sin balanceo, {num(b.loc['SMOTE', 'recall'], 3)} con SMOTE, {num(b.loc['ADASYN', 'recall'], 3)} con ADASYN y "
        f"{num(b.loc['class_weight', 'recall'], 3)} con class_weight; el AUC-PR medio se mueve entre "
        f"{num(b['auc_pr'].min(), 3)} y {num(b['auc_pr'].max(), 3)}.",
        "Esto significa que el balanceo desplaza las probabilidades hacia arriba: con el umbral de 0,5 se marcan más "
        "clientes, sube el recall y empeora la calibración, pero el orden de los clientes casi no cambia.",
        "En consecuencia, se decide usar el balanceo solo cuando se quiera más recall con el umbral por defecto, y "
        "preferir class_weight porque no crea datos sintéticos.",
    ]


def optimizadores():
    f = objeto("friedman_opt")
    r = f["clf"]["rangos"]
    mejor = min(r, key=r.get)
    return [
        f"**Interpretación.** Con 20 configuraciones por pliegue, Friedman sobre {f['clf']['n']} bloques de "
        f"clasificación da χ² = {num(f['clf']['chi2'], 2)} ({p_txt(f['clf']['p'])}); el mejor rango promedio es el de "
        f"{mejor} ({num(r[mejor], 2)}). En regresión, χ² = {num(f['reg']['chi2'], 2)} ({p_txt(f['reg']['p'])}).",
        ("Esto significa que el método de búsqueda cambia de forma sistemática el modelo que llega al bucle externo, "
         "aunque mucho menos que la elección del modelo." if f["clf"]["p"] < 0.05 else
         "Esto significa que, con este presupuesto, no hay evidencia de que el método de búsqueda cambie la calidad "
         "final del modelo."),
        "Por lo anterior, conviene juzgar la eficiencia por la rapidez con que cada método llega a buenas "
        "soluciones (curvas anytime), no solo por el valor final.",
    ]


def eficiencia():
    e = tabla("eficiencia")
    e = e[e["tarea"] == "clf"].set_index("optimizador")["AUAC evaluaciones"]
    p = tabla("eficiencia_pruebas")
    p = p[p["AUAC frente a"] == "evaluaciones"]
    sig = int((p["p Holm"] < 0.05).sum())
    return [
        "**Interpretación.** El área bajo la curva anytime (1 = llegar al mejor valor desde la primera evaluación) es "
        + enumerar([f"{num(v, 3)} con {k}" for k, v in e.items()]) + f"; {sig} de {len(p)} comparaciones por pares "
        "son significativas tras el ajuste de Holm.",
        "Hay que tener en cuenta que los métodos adaptativos superan con claridad a la rejilla, pero frente a Random "
        "Search la ventaja es pequeña: las primeras 5 evaluaciones de Optuna y las 6 de la población inicial del "
        "genético son aleatorias, así que con 20 evaluaciones su ventaja adaptativa tiene poco margen para aparecer.",
        "Así las cosas, se decide leer la eficiencia como un resultado condicionado al presupuesto y a la dimensión "
        "del espacio, con su tamaño de efecto (delta de Cliff) junto al valor p.",
    ]


def prueba():
    f = tabla("finalistas_prueba")
    m = f[~f["clave"].str.endswith("e2")]
    b = m.loc[m["AUC-PR"].idxmax()]
    r = f[f["clave"].str.endswith("e2")].iloc[0]
    c = objeto("contexto")
    return [
        f"**Interpretación.** En prueba, el mayor AUC-PR es el de {b['Modelo']} ({num(b['AUC-PR'], 3)} "
        f"{b['AUC-PR IC 95 %']}, AUC {num(b['AUC'], 3)}), frente a {num(r['AUC-PR'], 3)} de la referencia del "
        f"Entregable 2. La tasa de suscripción en prueba es del {pct(c['prev_te'])}, que es el AUC-PR de un "
        "clasificador al azar.",
        "Esto significa que los modelos ordenan bien a los clientes en un periodo que no vieron, pero el umbral por "
        "defecto, fijado con la tasa del entrenamiento, deja sin marcar a muchos suscriptores en los modelos sin "
        "balanceo.",
        "Por ello, se recomienda usar el orden (AUC y AUC-PR) para decidir a quién llamar primero y fijar el punto de "
        "operación con probabilidades recalibradas al régimen vigente.",
    ]


def calibracion():
    c = tabla("calibracion")
    med = c.groupby("Variante")["ECE"].median().sort_values()
    return [
        "**Interpretación.** La mediana del ECE en prueba por variante es "
        + enumerar([f"{num(v, 3)} ({k})" for k, v in med.items()]) + ".",
        "Esto quiere decir que la descalibración está dominada por el cambio de prevalencia: Platt y la isotónica se "
        "ajustan con datos del entrenamiento y no anticipan el régimen nuevo, mientras que la recalibración mensual "
        "sigue la tasa del último mes cerrado.",
        f"Por tal motivo, se opta por la variante {med.index[0]} cuando importe el valor de la probabilidad, por "
        "ejemplo para estimar cuántas suscripciones dará una campaña.",
    ]


def regresion():
    r = tabla("regresion_prueba")
    m = r[r["clave"] != "media"].sort_values("RMSE (log)").iloc[0]
    b = r[r["clave"] == "media"].iloc[0]
    res = objeto("regresion_residuos")
    return [
        f"**Interpretación.** El mejor modelo de regresión ({m['Modelo']}) logra un RMSE de {num(m['RMSE (log)'], 4)} en "
        f"escala log y un R² de {num(m['R²'], 3)}; la media del entrenamiento, {num(b['RMSE (log)'], 4)} y "
        f"{num(b['R²'], 3)}. En sus residuos, White da {p_txt(res['p_white'])} y Jarque-Bera {p_txt(res['p_jb'])}.",
        f"Esto significa que la información previa a la llamada explica apenas el {pct(max(m['R²'], 0), 0)} de la "
        "varianza de la duración: los modelos superan a la media de forma significativa, pero no anticipan qué "
        "llamadas serán muy cortas o muy largas, y los residuos heredan las colas pesadas y la dependencia de la "
        "propia duración.",
        "En consecuencia, se decide reportar la rama de regresión como un resultado de señal débil y no usarla para "
        "planificar la carga de los asesores llamada a llamada.",
    ]


def estadistica():
    o = tabla("friedman_omnibus")
    d = tabla("delong")
    mcs = tabla("mcs")
    fin = o.iloc[1]
    return [
        f"**Interpretación.** Entre los siete finalistas, Friedman da "
        f"{'p ' + str(fin['p (χ²)']) if str(fin['p (χ²)']).startswith('<') else 'p = ' + str(fin['p (χ²)'])} "
        f"con una diferencia crítica de Nemenyi de {num(fin['Diferencia crítica de Nemenyi'], 2)} rangos; DeLong "
        f"confirma {int((d['p Holm'] < 0.05).sum())} de {len(d)} diferencias dirigidas tras el ajuste de Holm. En "
        f"regresión, el Model Confidence Set conserva {int(mcs['en_conjunto'].sum())} de {len(mcs)} modelos.",
        ("Lo anterior indica que los finalistas y el modelo base del Entregable 2 son estadísticamente equivalentes: "
         "ninguna diferencia de AUC es significativa, ni siquiera con más de 8 000 observaciones de prueba."
         if (d["p Holm"] >= 0.05).all() else
         "Lo anterior indica que varias diferencias entre los mejores modelos no superan la variabilidad entre "
         "periodos; con más de 8 000 observaciones de prueba, DeLong detecta diferencias pequeñas que importan poco "
         "en la práctica."),
        "Por tanto, corresponde elegir entre los modelos equivalentes por costo, calibración e interpretabilidad, "
        "criterios con los que la logística regularizada del Entregable 2 sigue siendo muy competitiva.",
    ]


def interpretabilidad():
    s = tabla("shap_global")
    l = tabla("lime_shap")
    return [
        f"**Interpretación.** En {s['modelo'].iloc[0]}, las variables con mayor contribución SHAP media son "
        + enumerar([f"`{v}`" for v in s["variable"].head(4)]) + ". SHAP y LIME comparten "
        + enumerar([str(v) for v in l["Variables comunes en el top 10"]]) + " de sus 10 variables principales en las "
        "dos observaciones explicadas.",
        "Esto significa que el modelo se apoya sobre todo en el régimen de la campaña (contexto macroeconómico y "
        "calendario) y en el historial de contactos; LIME coincide en lo esencial, pero su modelo lineal local y sus "
        "perturbaciones independientes alteran el orden del resto.",
        "Por ello, se recomienda usar SHAP como explicación de referencia y leer las contribuciones como asociaciones, "
        "no como efectos causales.",
    ]


def computacional():
    co = tabla("comp_comparativa")
    pc = tabla("comp_perfil_componentes")
    g = co.groupby("Modelo", sort=False)
    ajuste = g.apply(lambda d: d["Ajuste (s)"].iloc[0] / d["Ajuste (s)"].iloc[1], include_groups=False)
    inferencia = g.apply(lambda d: d["Inferencia (s)"].iloc[0] / d["Inferencia (s)"].iloc[1], include_groups=False)
    dom = pc.iloc[0]

    def veces(v, fem=False):
        if 0.9 <= v <= 1.1:
            return "similar"
        a = "a" if fem else "o"
        return f"{num(v, 1)} veces más rápid{a}" if v > 1 else f"{num(1 / v, 0)} veces más lent{a}"

    return [
        "**Interpretación.** Frente a la versión estándar, el ajuste de la versión optimizada es "
        + enumerar([f"{veces(v)} ({k})" for k, v in ajuste.items()]) + "; la inferencia es "
        + enumerar([f"{veces(v, True)} ({k})" for k, v in inferencia.items()])
        + f". En el perfil de una combinación completa, \"{dom['Componente']}\" concentra el "
          f"{num(dom['% del total'], 1)} % del tiempo.",
        "Es decir, el cuello de botella es el ajuste de los modelos y no el optimizador. Los histogramas de XGBoost "
        "abaratan el ajuste sin perder desempeño, FAISS abarata cada consulta a costa de construir el índice y Nyström "
        "abarata la SVM; SAGA, en cambio, es mucho más lento que Cholesky con 49 columnas.",
        "Así las cosas, se decide mantener esas versiones en el pipeline y paralelizar al nivel de tarea, que es el "
        "más grueso disponible.",
    ]
