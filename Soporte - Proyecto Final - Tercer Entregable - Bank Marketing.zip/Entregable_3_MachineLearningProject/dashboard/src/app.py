"""Dashboard del tercer entregable del proyecto final (Bank Marketing, UCI)."""

import argparse
import os

import pandas as pd
from dash import Dash, Input, Output, dash_table, dcc, html
from dash.dash_table.Format import Format, Group, Scheme

from . import figuras as fg
from . import textos as tx
from .datos import RAIZ, num, objeto, pct, tabla

JBOOK_URL = os.environ.get("JBOOK_URL", "")


# ------------------------------------------------------------------------------------------------ componentes

def grafico(fig):
    return html.Div(dcc.Graph(figure=fig, config=fg.CONFIG), className="chart-card")


def narrativa(parrafos):
    return html.Div(dcc.Markdown("\n\n".join(parrafos)), className="narrative-card")


def titulo(texto, subtitulo=None):
    hijos = [html.H2(texto)]
    if subtitulo:
        hijos.append(html.P(subtitulo, className="section-subtitle"))
    return html.Div(hijos, className="section-heading")


def tarjeta(etiqueta, valor, nota):
    return html.Div([html.Div(etiqueta, className="metric-label"), html.Div(valor, className="metric-value"),
                     html.Div(nota, className="metric-note")], className="metric-card")


def tabla_dash(df, titulo_tabla=None, dec=3, filas=12, id_=None, ordenable=True):
    df = df.copy()
    columnas = []
    for c in df.columns:
        if pd.api.types.is_bool_dtype(df[c]):
            df[c] = df[c].map({True: "Sí", False: "No"})
        if pd.api.types.is_numeric_dtype(df[c]) and not pd.api.types.is_bool_dtype(df[c]):
            entera = df[c].dropna().apply(lambda v: float(v).is_integer()).all()
            fmt = Format(precision=0 if entera else dec, scheme=Scheme.fixed, group=Group.yes)
            columnas.append({"name": str(c), "id": str(c), "type": "numeric", "format": fmt})
        else:
            df[c] = df[c].astype(str)
            columnas.append({"name": str(c), "id": str(c)})
    df.columns = [str(c) for c in df.columns]
    tabla_ = dash_table.DataTable(
        data=df.to_dict("records"), columns=columnas, page_size=filas, sort_action="native" if ordenable else "none",
        locale_format={"decimal": ",", "group": " "}, style_table={"overflowX": "auto"},
        style_cell={"fontFamily": "DM Sans, Segoe UI, sans-serif", "padding": "6px 8px", "textAlign": "left",
                    "whiteSpace": "normal", "height": "auto", "maxWidth": 340},
        style_header={"fontWeight": "700"}, **({"id": id_} if id_ else {}))
    hijos = [html.Div(titulo_tabla, className="table-title")] if titulo_tabla else []
    return html.Div(hijos + [tabla_], className="chart-card")


def filtro(etiqueta, id_, opciones, valor, multi=False):
    return html.Div([html.Label(etiqueta, htmlFor=id_),
                     dcc.Dropdown(id=id_, options=opciones, value=valor, clearable=False, multi=multi)],
                    className="filter")


# ------------------------------------------------------------------------------------------------ pestañas

def pestana_contexto():
    c = objeto("contexto")
    return html.Div([
        titulo("Contexto y diseño experimental",
               "Predicción de la suscripción a depósitos a término con información previa a la llamada"),
        html.Div([
            tarjeta("Llamadas analizadas", num(c["registros_limpios"]), f"{num(c['n_tr'])} entrenamiento · "
                    f"{num(c['n_te'])} prueba"),
            tarjeta("Suscripción", f"{pct(c['prev_tr'])} → {pct(c['prev_te'])}", "entrenamiento → prueba"),
            tarjeta("Combinaciones", str(c["combinaciones"]), "112 de clasificación · 28 de regresión"),
            tarjeta("Ajustes de modelos", num(c["ajustes"]), f"{num(c['horas_cpu'], 1)} horas de CPU"),
        ], className="metric-grid"),
        grafico(fg.esquema_anidado()),
        html.Div([tabla_dash(tabla("desglose"), "Explosión combinatoria", dec=0, ordenable=False),
                  tabla_dash(tabla("esquema_anidado"), "Pliegues externos", dec=1, ordenable=False)],
                 className="two-column"),
        narrativa(tx.contexto()),
    ])


def pestana_maestra():
    m = tabla("maestra")
    return html.Div([
        titulo("Tabla maestra y balanceo", "Las 140 combinaciones evaluadas en el bucle externo de la validación anidada"),
        html.Div([
            filtro("Tarea", "f-tarea", [{"label": "Clasificación", "value": "clf"}, {"label": "Regresión", "value": "reg"}],
                   "clf"),
            filtro("Modelo", "f-modelo", sorted(m["Modelo"].unique()), [], multi=True),
            filtro("Balanceo", "f-balanceo", fg.BALANCEOS, [], multi=True),
            filtro("Optimizador", "f-optimizador", fg.OPTIMIZADORES[:5], [], multi=True),
        ], className="filters-row"),
        html.Div(id="maestra-tabla"),
        tabla_dash(tabla("auc_por_pliegue"), "AUC externo por modelo y pliegue (máximo entre combinaciones)",
                   ordenable=False),
        narrativa(tx.por_pliegue()),
        grafico(fg.mapa_balanceo()),
        narrativa(tx.mapa_balanceo()),
        html.Div([filtro("Métrica del balanceo", "f-metrica-bal",
                         [{"label": n, "value": v} for v, n in (("recall", "Recall"), ("f1", "F1"),
                                                                ("auc_pr", "AUC-PR"), ("auc", "AUC"),
                                                                ("precision", "Precision"), ("brier", "Brier"))],
                         "recall")], className="filters-row"),
        html.Div(id="balanceo-grafico"),
        tabla_dash(tabla("balanceo_pruebas"), "Cada técnica frente a sin balanceo (Wilcoxon por bloques, Holm y Cliff)",
                   dec=4),
        narrativa(tx.balanceo()),
    ])


def pestana_optimizacion():
    return html.Div([
        titulo("Optimización de hiperparámetros", "Grid, Random, Bayesiana (TPE), Genética (DEAP) y Successive Halving "
                                                  "con el mismo presupuesto"),
        html.Div([tabla_dash(tabla("opt_clf").rename(columns={"index": "Método"}), "Clasificación (AUC-PR externo)"),
                  tabla_dash(tabla("opt_reg").rename(columns={"index": "Método"}), "Regresión (RMSE externo)", dec=4)],
                 className="two-column"),
        narrativa(tx.optimizadores()),
        html.Div([
            filtro("Grupo", "f-grupo", [{"label": "Clasificación", "value": "clf"}, {"label": "Regresión", "value": "reg"}], "clf"),
            filtro("Eje horizontal", "f-eje", [{"label": "Evaluaciones", "value": "evaluaciones"},
                                               {"label": "Tiempo relativo", "value": "tiempo"}], "evaluaciones"),
        ], className="filters-row"),
        html.Div(id="anytime-grafico"),
        html.Div([grafico(fg.optuna_ejemplo()), grafico(fg.params_optuna("Bayesiana (Optuna TPE)"))],
                 className="two-column"),
        tabla_dash(tabla("eficiencia").rename(columns={"optimizador": "Método", "tarea": "Tarea"}),
                   "Área bajo la curva anytime (AUAC)"),
        tabla_dash(tabla("eficiencia_pruebas"), "Comparaciones por pares del AUAC (Wilcoxon, Holm y Cliff)", dec=4),
        narrativa(tx.eficiencia()),
        grafico(fg.diversidad_genetico()),
        html.Div([tabla_dash(tabla("halving"), "Successive Halving frente a Random y Optuna", dec=2),
                  tabla_dash(tabla("semillas_optimizador").rename(columns={"index": "Método"}),
                             "Estabilidad ante semillas (XGBoost sin balanceo)", dec=4)], className="two-column"),
    ])


def pestana_prueba():
    f = tabla("finalistas_prueba")
    modelos = [m for m in fg.MODELOS + ["Referencia E2"] if m in set(tabla("curvas_prueba")["modelo"])]
    return html.Div([
        titulo("Evaluación en el conjunto de prueba", "Mejor combinación de cada modelo, reajustada con todo el "
                                                       "entrenamiento y evaluada una sola vez (2009-2010)"),
        tabla_dash(f.drop(columns=["clave", "auc_inf", "auc_sup", "ap_inf", "ap_sup"]),
                   "Finalistas en prueba (umbral por defecto; IC 95 % bootstrap BCa)", ordenable=False),
        html.Div([filtro("Curva", "f-curva", [{"label": "ROC", "value": "ROC"},
                                              {"label": "Precisión-recall", "value": "PR"}], "ROC"),
                  filtro("Modelo", "f-modelo-prueba", modelos, modelos[0])], className="filters-row"),
        html.Div([html.Div(id="curva-grafico"), html.Div(id="confusion-grafico")], className="two-column"),
        narrativa(tx.prueba()),
        html.Div([html.Div(id="confiabilidad-grafico"),
                  tabla_dash(tabla("calibracion").drop(columns=["clave"]), "Calibración en prueba (Brier y ECE)",
                             dec=4)], className="two-column"),
        narrativa(tx.calibracion()),
        titulo("Regresión: duración de la llamada", "log1p(duration) con información previa a la llamada"),
        tabla_dash(tabla("regresion_prueba").drop(columns=["clave"]), "Finalistas de regresión en prueba", dec=4),
        grafico(fg.serie_regresion()),
        grafico(fg.residuos_regresion()),
        narrativa(tx.regresion()),
    ])


def pestana_estadistica():
    return html.Div([
        titulo("Comparación estadística", "Friedman → Nemenyi → DeLong (clasificación) · MCS → GW y Clark-West → "
                                          "Diebold-Mariano (regresión)"),
        tabla_dash(tabla("friedman_omnibus"), "Prueba ómnibus de Friedman", ordenable=False),
        html.Div([grafico(fg.rangos_cd("pliegues")), grafico(fg.rangos_cd("meses"))], className="two-column"),
        tabla_dash(tabla("delong"), "Comparaciones dirigidas con DeLong (Holm y Benjamini-Hochberg)", dec=4),
        html.Div([tabla_dash(tabla("mcs"), "Model Confidence Set al 90 % (regresión)", dec=4, filas=15),
                  tabla_dash(tabla("pruebas_regresion"), "Pruebas dirigidas de regresión en prueba", dec=4)],
                 className="two-column"),
        tabla_dash(tabla("intervalos"), "Intervalos de confianza al 95 % (bootstrap BCa)", dec=4, filas=15),
        narrativa(tx.estadistica()),
    ])


def pestana_interpretabilidad():
    return html.Div([
        titulo("Interpretabilidad y costo computacional", "SHAP, LIME y complejidad teórica frente a tiempos medidos"),
        html.Div([grafico(fg.shap_global()),
                  html.Div([grafico(fg.shap_local("Bien clasificada")), grafico(fg.shap_local("Error elevado"))])],
                 className="two-column"),
        tabla_dash(tabla("lime_shap"), "SHAP frente a LIME en XGBoost", dec=3),
        narrativa(tx.interpretabilidad()),
        tabla_dash(tabla("comp_complejidad"), "Complejidad teórica", filas=15, ordenable=False),
        html.Div([filtro("Experimento de escalamiento", "f-escala",
                         [{"label": "KNN (consulta)", "value": "knn_escalamiento|Consulta (s)"},
                          {"label": "Modelos lineales", "value": "lineales_escalamiento|Ajuste (s)"},
                          {"label": "XGBoost", "value": "xgboost_escalamiento|Ajuste (s)"},
                          {"label": "SVM", "value": "svm_escalamiento|Ajuste (s)"}], "svm_escalamiento|Ajuste (s)")],
                 className="filters-row"),
        html.Div([html.Div(id="escala-grafico"), grafico(fg.paralelizacion())], className="two-column"),
        tabla_dash(tabla("comp_comparativa"), "Modelo estándar frente a optimizado", dec=4),
        tabla_dash(tabla("comp_perfil_componentes"), "Perfilamiento de una combinación completa (cProfile)", dec=2),
        narrativa(tx.computacional()),
    ])


PESTANAS = {"contexto": ("1 · Contexto y diseño", pestana_contexto), "maestra": ("2 · Tabla maestra y balanceo",
                                                                                pestana_maestra),
            "optimizacion": ("3 · Optimización", pestana_optimizacion), "prueba": ("4 · Evaluación en prueba",
                                                                                   pestana_prueba),
            "estadistica": ("5 · Comparación estadística", pestana_estadistica),
            "interpretabilidad": ("6 · Interpretabilidad y cómputo", pestana_interpretabilidad)}


def crear_app() -> Dash:
    app = Dash(__name__, assets_folder=str(RAIZ / "assets"), title="Bank Marketing · Proyecto final",
               suppress_callback_exceptions=True)
    c = objeto("contexto")
    pie = ["Desarrollo completo e interpretaciones: "]
    pie += [html.A("Jupyter Book del proyecto", href=JBOOK_URL, target="_blank", rel="noopener noreferrer")] \
        if JBOOK_URL else ["Jupyter Book del proyecto (enlace en la entrega)"]
    pie += [" · validación anidada cronológica, semilla 42."]
    app.layout = html.Main([
        html.Header([
            html.Div([html.H1("Bank Marketing"),
                      html.P("Proyecto final · tercer entregable: optimización de hiperparámetros, costo "
                             "computacional y validación estadística", className="header-subtitle"),
                      html.Div([html.Span("DATOS UCI", className="hero-source"), html.Span("·", className="hero-divider"),
                                html.Span("Donny Torres · Universidad del Norte", className="hero-source")],
                               className="hero-footnote")], className="hero-copy"),
            html.Div([html.Div("COMBINACIONES", className="hero-stat-label"),
                      html.Strong(str(c["combinaciones"]), className="hero-stat-value"),
                      html.Div(f"{c['k_ext']} pliegues externos · {num(c['ajustes'])} ajustes",
                               className="hero-stat-note")], className="hero-stat"),
        ], className="hero"),
        dcc.Tabs(id="pestanas", value="contexto", className="main-tabs",
                 children=[dcc.Tab(label=n, value=k, className="tab", selected_className="tab-selected")
                           for k, (n, _) in PESTANAS.items()]),
        html.Div(id="contenido", className="page-content"),
        html.Footer(pie, className="footer"),
    ], className="app-shell")

    @app.callback(Output("contenido", "children"), Input("pestanas", "value"))
    def mostrar(pestana):
        return PESTANAS[pestana][1]()

    @app.callback(Output("maestra-tabla", "children"), Input("f-tarea", "value"), Input("f-modelo", "value"),
                  Input("f-balanceo", "value"), Input("f-optimizador", "value"))
    def filtrar(tarea, modelos, balanceos, optimizadores):
        m = tabla("maestra")
        m = m[m["tarea"] == tarea]
        if modelos:
            m = m[m["Modelo"].isin(modelos)]
        if tarea == "clf" and balanceos:
            m = m[m["Balanceo"].isin(balanceos)]
        if optimizadores:
            m = m[m["Optimizador"].isin(optimizadores)]
        if tarea == "clf":
            cols = ["Modelo", "Balanceo", "Optimizador", "auc_pr_media", "auc_pr_de", "auc_media", "recall_media",
                    "f1_media", "brier_media", "n_eval_total", "t_opt_total"]
            m = m.sort_values("auc_pr_media", ascending=False)
        else:
            cols = ["Modelo", "Optimizador", "rmse_media", "rmse_de", "mae_media", "r2_media", "rmse_seg_media",
                    "n_eval_total", "t_opt_total"]
            m = m.sort_values("rmse_media")
        nombres = {"auc_pr_media": "AUC-PR media", "auc_pr_de": "AUC-PR DE", "auc_media": "AUC media",
                   "recall_media": "Recall media", "f1_media": "F1 media", "brier_media": "Brier media",
                   "n_eval_total": "Evaluaciones", "t_opt_total": "Tiempo (s)", "rmse_media": "RMSE media",
                   "rmse_de": "RMSE DE", "mae_media": "MAE media", "r2_media": "R² media",
                   "rmse_seg_media": "RMSE (s) media"}
        return tabla_dash(m[cols].rename(columns=nombres), f"Tabla maestra filtrada ({len(m)} combinaciones)", dec=4)

    @app.callback(Output("balanceo-grafico", "children"), Input("f-metrica-bal", "value"))
    def bal(metrica):
        return grafico(fg.balanceo_barras(metrica))

    @app.callback(Output("anytime-grafico", "children"), Input("f-grupo", "value"), Input("f-eje", "value"))
    def any_(grupo, eje):
        return grafico(fg.anytime(grupo, eje))

    @app.callback(Output("curva-grafico", "children"), Output("confusion-grafico", "children"),
                  Output("confiabilidad-grafico", "children"), Input("f-curva", "value"),
                  Input("f-modelo-prueba", "value"))
    def prueba_(curva, modelo):
        return grafico(fg.curvas_prueba(curva)), grafico(fg.matriz_confusion(modelo)), grafico(fg.confiabilidad(modelo))

    @app.callback(Output("escala-grafico", "children"), Input("f-escala", "value"))
    def escala(valor):
        nombre, y = valor.split("|")
        return grafico(fg.escalamiento(nombre, y))

    return app


app = crear_app()
server = app.server


def main():
    ap = argparse.ArgumentParser(description="Dashboard del proyecto final de Bank Marketing.")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8050)
    args = ap.parse_args()
    app.run(host=args.host, port=args.port, debug=False)


if __name__ == "__main__":
    main()
