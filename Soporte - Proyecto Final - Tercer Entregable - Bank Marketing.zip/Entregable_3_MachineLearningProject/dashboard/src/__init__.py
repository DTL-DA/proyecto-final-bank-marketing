"""Paquete del dashboard."""
