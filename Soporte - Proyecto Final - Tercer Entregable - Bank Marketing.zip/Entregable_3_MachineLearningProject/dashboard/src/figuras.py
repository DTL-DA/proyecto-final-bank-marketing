"""Figuras Plotly del dashboard (las reutiliza el Jupyter Book para mostrar exactamente lo mismo)."""

import json

import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots

from .datos import num, objeto, tabla

# Paleta categórica validada, en orden fijo; la identidad sigue a la entidad, nunca a su rango
CAT = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300", "#6250d6", "#e34948"]
GRIS, TINTA, TINTA_2, REJILLA, FONDO = "#898781", "#0b0b0b", "#52514e", "#e1e0d9", "#ffffff"
SECUENCIAL = [[0, "#f0efec"], [0.33, "#9ec5f4"], [0.66, "#2a78d6"], [1, "#0d366b"]]
MODELOS = ["KNN", "Naive Bayes", "Logística L1/L2", "Árbol de decisión", "Random Forest", "XGBoost", "SVM"]
MODELOS_REG = ["KNN", "Ridge", "Lasso", "Árbol de decisión", "Random Forest", "XGBoost", "SVR"]
COLOR_MODELO = {m: CAT[i] for i, m in enumerate(MODELOS)} | {m: CAT[i] for i, m in enumerate(MODELOS_REG)}
COLOR_MODELO["Referencia E2"] = GRIS
OPTIMIZADORES = ["Grid Search", "Random Search", "Bayesiana (Optuna TPE)", "Genético (DEAP)",
                 "Successive Halving"]
COLOR_OPT = {o: CAT[i] for i, o in enumerate(OPTIMIZADORES)}
BALANCEOS = ["Sin balanceo", "SMOTE", "ADASYN", "class_weight"]
COLOR_BAL = {b: CAT[i] for i, b in enumerate(BALANCEOS)}
CONFIG = {"displayModeBar": False, "responsive": True}


def _base(fig, titulo=None, alto=380, x=None, y=None):
    fig.update_layout(
        title={"text": titulo, "x": 0, "font": {"size": 14, "color": TINTA}} if titulo else None,
        height=alto, margin={"l": 60, "r": 20, "t": 50 if titulo else 20, "b": 50},
        paper_bgcolor=FONDO, plot_bgcolor=FONDO, font={"family": "DM Sans, Segoe UI, sans-serif", "size": 12,
                                                         "color": TINTA_2},
        legend={"orientation": "h", "y": -0.22, "x": 0, "font": {"size": 11}}, hovermode="closest",
        separators=", ")
    fig.update_xaxes(title=x, gridcolor=REJILLA, zeroline=False, linecolor="#c3c2b7")
    fig.update_yaxes(title=y, gridcolor=REJILLA, zeroline=False, linecolor="#c3c2b7")
    return fig


def _rgba(hexa, a):
    h = hexa.lstrip("#")
    return f"rgba({int(h[0:2], 16)}, {int(h[2:4], 16)}, {int(h[4:6], 16)}, {a})"


# ------------------------------------------------------------------------------------------ Pestaña 1

def esquema_anidado():
    """Línea de tiempo de la validación anidada (bucle externo)."""
    e = tabla("esquema_anidado")
    ctx = objeto("contexto")
    fig = go.Figure()
    for _, r in e.iterrows():
        k = int(r["Pliegue externo"])
        ajuste, val = int(r["Registros de ajuste"]), int(r["Registros de validación"])
        fig.add_bar(y=[f"Externo {k}"], x=[ajuste], orientation="h", marker_color=CAT[0], name="Ajuste externo",
                    showlegend=k == 1, hovertemplate=f"Ajuste: {num(ajuste)} registros (hasta {r['Ajusta hasta']})"
                                                     "<extra></extra>")
        fig.add_bar(y=[f"Externo {k}"], x=[ctx["gap"]], orientation="h", marker_color=GRIS, name="Separación (gap)",
                    showlegend=k == 1, hovertemplate=f"Separación: {ctx['gap']} registros<extra></extra>")
        fig.add_bar(y=[f"Externo {k}"], x=[val], orientation="h", marker_color=CAT[1], name="Validación externa",
                    showlegend=k == 1, hovertemplate=f"Validación: {num(val)} registros, {r['Valida desde']} a "
                                                     f"{r['Valida hasta']} ({num(r['% positivos validación'], 1)} % "
                                                     "positivos)<extra></extra>")
    fig.update_layout(barmode="stack", bargap=0.35)
    fig.update_yaxes(autorange="reversed")
    return _base(fig, "Validación anidada: 5 pliegues externos en orden temporal", 330,
                 x="Registros de entrenamiento (orden temporal)")


# ------------------------------------------------------------------------------------------ Pestaña 2

def mapa_balanceo():
    m = tabla("mapa_balanceo").set_index("modelo")
    z = m.to_numpy()
    fig = go.Figure(go.Heatmap(z=z, x=list(m.columns), y=list(m.index), colorscale=SECUENCIAL,
                               text=[[num(v, 3) for v in fila] for fila in z], texttemplate="%{text}",
                               hovertemplate="%{y} · %{x}<br>AUC-PR externo: %{text}<extra></extra>",
                               colorbar={"title": "AUC-PR"}))
    fig.update_yaxes(autorange="reversed")
    return _base(fig, "Mejor AUC-PR del bucle externo por modelo y balanceo", 380)


def balanceo_barras(metrica="recall"):
    b = tabla("balanceo_modelo")
    nombres = {"recall": "Recall (umbral por defecto)", "f1": "F1 (umbral por defecto)", "auc_pr": "AUC-PR",
               "auc": "AUC", "precision": "Precision", "brier": "Brier"}
    fig = go.Figure()
    for bal in BALANCEOS:
        d = b[b["Balanceo"] == bal].set_index("Modelo").reindex(MODELOS)
        fig.add_bar(x=d.index, y=d[metrica], name=bal, marker_color=COLOR_BAL[bal],
                    hovertemplate="%{x} · " + bal + "<br>" + nombres[metrica] + ": %{y:.3f}<extra></extra>")
    fig.update_layout(barmode="group", bargap=0.25, bargroupgap=0.05)
    return _base(fig, f"{nombres[metrica]} por modelo y técnica de balanceo", 400, y=nombres[metrica])


# ------------------------------------------------------------------------------------------ Pestaña 3

def anytime(grupo="clf", eje="evaluaciones"):
    a = tabla("anytime")
    a = a[(a["grupo"] == grupo) & (a["eje"] == eje)]
    fig = go.Figure()
    for o in OPTIMIZADORES:
        d = a[a["optimizador"] == o]
        if d.empty:
            continue
        c = COLOR_OPT[o]
        fig.add_scatter(x=list(d["x"]) + list(d["x"])[::-1], y=list(d["q3"]) + list(d["q1"])[::-1], fill="toself",
                        fillcolor=_rgba(c, 0.12), line={"width": 0}, hoverinfo="skip", showlegend=False)
        fig.add_scatter(x=d["x"], y=d["mediana"], mode="lines+markers", name=o, line={"color": c, "width": 2},
                        marker={"size": 5}, hovertemplate=o + "<br>x = %{x:.2f}<br>Mediana: %{y:.3f}<extra></extra>")
    x = "Evaluación t" if eje == "evaluaciones" else "Tiempo acumulado / tiempo del método más lento"
    titulo = {"clf": "Clasificación", "reg": "Regresión"}[grupo]
    fig.update_yaxes(range=[0, 1.03])
    return _base(fig, f"Curvas anytime · {titulo} (mediana y rango intercuartílico)", 400, x=x,
                 y="Mejor puntaje normalizado del bloque")


def optuna_ejemplo():
    e = tabla("optuna_ejemplo")
    fig = go.Figure()
    for o in ("Random Search", "Bayesiana (Optuna TPE)"):
        d = e[e["optimizador"] == o]
        fig.add_scatter(x=d["n"], y=d["puntaje"], mode="markers", name=f"{o}: evaluación",
                        marker={"color": COLOR_OPT[o], "size": 8, "opacity": 0.6,
                                "line": {"color": FONDO, "width": 1.5}})
        fig.add_scatter(x=d["n"], y=d["mejor"], mode="lines", name=f"{o}: mejor hasta t", line_shape="hv",
                        line={"color": COLOR_OPT[o], "width": 2})
    fig.add_vline(x=5.5, line_dash="dash", line_color=GRIS)
    return _base(fig, "Historia de la optimización · XGBoost sin balanceo, último pliegue", 380, x="Evaluación t",
                 y="AUC-PR interno")


def diversidad_genetico():
    d = tabla("genetico_diversidad")
    c = CAT[3]
    fig = go.Figure()
    fig.add_scatter(x=list(d["generacion"]) + list(d["generacion"])[::-1], y=list(d["q75"]) + list(d["q25"])[::-1],
                    fill="toself", fillcolor=_rgba(c, 0.15), line={"width": 0}, hoverinfo="skip", showlegend=False)
    fig.add_scatter(x=d["generacion"], y=d["diversidad_mediana"], mode="lines+markers", line={"color": c, "width": 2},
                    marker={"size": 8}, name="Diversidad mediana",
                    hovertemplate="Generación %{x}<br>Diversidad: %{y:.3f}<extra></extra>")
    return _base(fig, "Diversidad genética por generación (mediana y RIC)", 340, x="Generación",
                 y="Distancia media / √d")


# ------------------------------------------------------------------------------------------ Pestaña 4

def curvas_prueba(tipo="ROC"):
    c = tabla("curvas_prueba")
    c = c[c["curva"] == tipo]
    f = tabla("finalistas_prueba").set_index("Modelo")
    fig = go.Figure()
    for m in MODELOS + ["Referencia E2"]:
        d = c[c["modelo"] == m]
        if d.empty:
            continue
        clave = next((i for i in f.index if i.startswith(m)), None)
        valor = f.loc[clave, "AUC" if tipo == "ROC" else "AUC-PR"] if clave else np.nan
        fig.add_scatter(x=d["x"], y=d["y"], mode="lines", name=f"{m} ({num(valor, 3)})",
                        line={"color": COLOR_MODELO[m], "width": 2, "dash": "dash" if m == "Referencia E2" else "solid"},
                        hovertemplate=m + "<br>x = %{x:.3f}<br>y = %{y:.3f}<extra></extra>")
    if tipo == "ROC":
        fig.add_scatter(x=[0, 1], y=[0, 1], mode="lines", line={"color": REJILLA, "width": 1}, showlegend=False,
                        hoverinfo="skip")
        return _base(fig, "Curvas ROC en prueba (AUC)", 430, x="Tasa de falsos positivos",
                     y="Tasa de verdaderos positivos")
    return _base(fig, "Curvas precisión-recall en prueba (AUC-PR)", 430, x="Recall", y="Precision")


def matriz_confusion(modelo):
    c = tabla("curvas_prueba")
    d = c[(c["curva"] == "CM") & (c["modelo"] == modelo)]
    z = np.zeros((2, 2))
    for _, r in d.iterrows():
        z[int(r["x"]), int(r["y"])] = r["valor"]
    fig = go.Figure(go.Heatmap(z=z, x=["Pred.: no", "Pred.: sí"], y=["Real: no", "Real: sí"], colorscale=SECUENCIAL,
                               text=[[num(v) for v in fila] for fila in z], texttemplate="%{text}", showscale=False,
                               hovertemplate="%{y} · %{x}: %{text}<extra></extra>"))
    fig.update_yaxes(autorange="reversed")
    return _base(fig, f"Matriz de confusión en prueba · {modelo}", 340)


def confiabilidad(modelo):
    c = tabla("calibracion_curvas")
    d = c[c["modelo"] == modelo]
    fig = go.Figure()
    for i, (v, g) in enumerate(d.groupby("variante", sort=False)):
        fig.add_scatter(x=g["prob_media"], y=g["frecuencia"], mode="lines+markers", name=v,
                        line={"color": CAT[i], "width": 2}, marker={"size": 7},
                        hovertemplate=v + "<br>Predicha: %{x:.3f}<br>Observada: %{y:.3f}<extra></extra>")
    fig.add_scatter(x=[0, 1], y=[0, 1], mode="lines", line={"color": GRIS, "dash": "dash", "width": 1},
                    name="Calibración perfecta")
    return _base(fig, f"Diagrama de confiabilidad en prueba · {modelo}", 400, x="Probabilidad predicha",
                 y="Frecuencia observada")


def serie_regresion():
    s = tabla("regresion_serie")
    r = objeto("regresion_residuos")
    fig = go.Figure()
    fig.add_scatter(x=s["dia"], y=s["observado"], mode="lines", name="Observado (media diaria)",
                    line={"color": GRIS, "width": 1})
    tr, te = s[s["conjunto"] == "entrenamiento"], s[s["conjunto"] == "prueba"]
    fig.add_scatter(x=tr["dia"], y=tr["predicho"], mode="lines", name="Ajuste en entrenamiento",
                    line={"color": CAT[0], "width": 2})
    v = s.dropna(subset=["validacion"])
    fig.add_scatter(x=v["dia"], y=v["validacion"], mode="lines", name="Validación (bucle externo)",
                    line={"color": CAT[2], "width": 2})
    fig.add_scatter(x=te["dia"], y=te["predicho"], mode="lines", name="Prueba", line={"color": CAT[1], "width": 2})
    return _base(fig, f"{r['modelo']}: log1p(duration) observado y predicho por día de contacto", 400,
                 x="Día de contacto (orden temporal)", y="log1p(duration), media diaria")


def residuos_regresion():
    r = objeto("regresion_residuos")
    fig = make_subplots(1, 2, subplot_titles=("ACF de los residuos en prueba", "Histograma de residuos en prueba"))
    fig.add_bar(x=list(range(1, len(r["acf"]) + 1)), y=r["acf"], marker_color=CAT[0], row=1, col=1, showlegend=False,
                hovertemplate="Rezago %{x}: %{y:.3f}<extra></extra>")
    for s in (1, -1):
        fig.add_hline(y=s * r["lim"], line_dash="dash", line_color=GRIS, row=1, col=1)
    b = np.array(r["bordes"])
    fig.add_bar(x=(b[1:] + b[:-1]) / 2, y=r["hist"], marker_color=CAT[0], row=1, col=2, showlegend=False,
                hovertemplate="Residuo %{x:.2f}: %{y} llamadas<extra></extra>")
    return _base(fig, None, 340)


# ------------------------------------------------------------------------------------------ Pestaña 5

def rangos_cd(bloques="pliegues"):
    r = tabla("rangos_cd")
    r = r[r["bloques"] == bloques].sort_values("rango")
    cd = float(r["cd"].iloc[0])
    mejor = float(r["rango"].iloc[0])
    fig = go.Figure()
    fig.add_shape(type="rect", x0=mejor, x1=mejor + cd, y0=-0.5, y1=len(r) - 0.5, fillcolor=_rgba(CAT[0], 0.08),
                  line={"width": 0})
    fig.add_scatter(x=r["rango"], y=r["modelo"], mode="markers", marker={"size": 12, "color": [
        COLOR_MODELO.get(m, GRIS) for m in r["modelo"]], "line": {"color": FONDO, "width": 2}},
                    hovertemplate="%{y}: rango promedio %{x:.2f}<extra></extra>", showlegend=False)
    fig.update_yaxes(autorange="reversed")
    return _base(fig, f"Rango promedio (1 = mejor) · bloques = {bloques} · franja = diferencia crítica de Nemenyi "
                      f"({num(cd, 2)})", 360, x="Rango promedio")


# ------------------------------------------------------------------------------------------ Pestaña 6

def shap_global():
    s = tabla("shap_global").sort_values("media_abs_shap")
    fig = go.Figure(go.Bar(x=s["media_abs_shap"], y=s["variable"], orientation="h", marker_color=CAT[0],
                           hovertemplate="%{y}: %{x:.4f}<extra></extra>"))
    return _base(fig, f"SHAP global · {s['modelo'].iloc[0]} (media del valor absoluto)", 460, x="Media |SHAP|")


def shap_local(caso):
    s = tabla("shap_local")
    d = s[s["caso"] == caso].iloc[::-1]
    fig = go.Figure(go.Bar(x=d["shap"], y=d["variable"], orientation="h",
                           marker_color=[CAT[1] if v > 0 else CAT[0] for v in d["shap"]],
                           hovertemplate="%{y}: %{x:.3f}<extra></extra>"))
    fila = d.iloc[0]
    return _base(fig, f"{caso}: y = {int(fila['y'])}, puntaje = {num(fila['puntaje'], 3)} (naranja sube, azul baja)",
                 380, x="Contribución SHAP")


def escalamiento(nombre, y="Ajuste (s)"):
    d = tabla(f"comp_{nombre}")
    fig = go.Figure()
    for i, (m, g) in enumerate(d.groupby("Método", sort=False)):
        fig.add_scatter(x=g["n"], y=g[y], mode="lines+markers", name=m, line={"color": CAT[i], "width": 2},
                        marker={"size": 7}, hovertemplate=m + "<br>n = %{x}<br>%{y:.3f} s<extra></extra>")
    fig.update_xaxes(type="log")
    fig.update_yaxes(type="log")
    return _base(fig, f"Escalamiento empírico ({y.lower()}, escalas log)", 380, x="n", y=y)


def paralelizacion():
    d = tabla("comp_paralelizacion")
    fig = go.Figure()
    for i, ((niv, be), g) in enumerate(d.groupby(["Nivel", "Backend"], sort=False)):
        fig.add_scatter(x=g["n_jobs"], y=g["Aceleración"], mode="lines+markers", name=f"{niv} · {be}",
                        line={"color": CAT[i], "width": 2}, marker={"size": 7})
    n = sorted(d["n_jobs"].unique())
    fig.add_scatter(x=n, y=n, mode="lines", line={"color": GRIS, "dash": "dash", "width": 1}, name="Ideal")
    return _base(fig, "Aceleración por paralelización", 380, x="n_jobs", y="Aceleración")


def params_optuna(o):
    e = tabla("optuna_ejemplo")
    d = e[e["optimizador"] == o]
    p = [json.loads(x) for x in d["params"]]
    fig = go.Figure(go.Scatter(x=[q["modelo__learning_rate"] for q in p], y=[q["modelo__n_estimators"] for q in p],
                               mode="markers", marker={"size": 6 + d["n"] * 0.8, "color": d["puntaje"],
                                                       "colorscale": SECUENCIAL, "showscale": True,
                                                       "colorbar": {"title": "AUC-PR"},
                                                       "line": {"color": FONDO, "width": 1.5}},
                               hovertemplate="learning_rate %{x:.3f}<br>árboles %{y}<extra></extra>"))
    fig.update_xaxes(type="log")
    return _base(fig, f"{o}: configuraciones visitadas", 360, x="learning_rate (log)", y="n_estimators")
