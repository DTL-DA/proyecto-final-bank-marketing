from src.app import server  # noqa: F401
