# Proyecto final · Tercer entregable · Bank Marketing (UCI)

Modelos de Machine Learning para clasificación y regresión con optimización de hiperparámetros, optimización computacional y validación estadística. Donny Torres · Maestría en Analítica de Datos, Universidad del Norte.

## Entregables

| Entregable | Ubicación |
|---|---|
| Cuaderno completo (código, resultados e interpretaciones) | `Proyecto Final - Tercer Entregable - Bank Marketing.ipynb` |
| Jupyter Book en línea | https://dtl-da.github.io/proyecto-final-bank-marketing/ (fuentes en `libro/`) |
| Dashboard de análisis (Dash + Plotly) | `dashboard/` (`python dashboard/app.py`) |
| Dashboard predictivo en línea | https://proyecto-final-bank-marketing.onrender.com (plan gratuito de Render: la primera carga tras 15 minutos sin visitas tarda cerca de un minuto y medio) |
| Tabla maestra de las 140 combinaciones | `resultados/tabla_maestra.csv` y `.parquet` |

## Diseño

- **Clasificación** de `y` (suscribe o no) con información previa a la llamada: 7 modelos × 4 balanceos × 4 optimizadores = 112.
- **Regresión** de `log1p(duration)`: 7 modelos × 4 optimizadores = 28. Total: 140 combinaciones.
- **Validación anidada cronológica:** `TimeSeriesSplit` de 5 pliegues externos y 3 internos con separación de un día de contactos; 20 configuraciones por optimizador y pliegue. Prueba: último 20 % (2009-2010), usada una sola vez.

## Reproducción

```bash
conda create -n bm_e3 python=3.12
conda activate bm_e3
pip install -r requirements.txt
python -m ipykernel install --user --name bm_e3

python scripts/ejecutar_experimentos.py                 # validación anidada (≈ 2 h con 10 núcleos, reanudable)
python scripts/ejecutar_finales.py --computacional      # finalistas, recalibración, semillas y sección 4 de la guía
python scripts/construir_cuaderno.py --origen "Entregable 2 - Bank Marketing.ipynb" --ejecutar   # arma y ejecuta el cuaderno
powershell libro_herramientas/construir_todo.ps1         # Jupyter Book
python dashboard/app.py                                  # dashboard en http://127.0.0.1:8050
python scripts/exportar_dashboard.py --app "<carpeta del dashboard predictivo>"   # artefactos del dashboard predictivo
```

## Estructura

```
data/                   bank-additional-full.csv
src/bm/                 paquete del proyecto (datos, preprocesamiento, modelos, espacios, optimizadores,
                        validación anidada, evaluación, estadística, costo computacional)
scripts/                ejecución de experimentos, fase final y armado del cuaderno (celdas en scripts/celdas)
resultados/             corridas por tarea, tabla maestra, historial, predicciones fuera de muestra, finales
dashboard/              aplicación Dash; lee los resultados que exporta el cuaderno en dashboard/datos
libro_herramientas/     construcción del Jupyter Book
```

Las corridas en bruto (`resultados/corridas`, `resultados/finales` y `resultados/oof.parquet`, unos 277 MB) se regeneran con los dos primeros comandos de la reproducción; la copia de soporte comprimida no las incluye por tamaño.

Semilla global: `SEED = 42` (`src/bm/config.py`), propagada a numpy, scikit-learn, XGBoost, SMOTE/ADASYN, Optuna y DEAP.
