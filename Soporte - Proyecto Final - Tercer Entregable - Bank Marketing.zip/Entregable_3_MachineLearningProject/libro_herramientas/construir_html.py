"""Construye el HTML del libro con Jupyter Book 1 y lo deja en `libro_html/`.

Se construye en una ruta corta (TEMP\jb3\libro) porque la ruta del proyecto supera el límite de 260 caracteres de
Windows. Se ejecuta con el Python 3.11 del entorno `ml_venv` y las librerías de `.venvs\jb1` en PYTHONPATH.
"""
import os
import pathlib
import shutil
import sys

RAIZ = pathlib.Path(__file__).resolve().parent.parent
FUENTE = RAIZ / "libro"
TEMPORAL = pathlib.Path(os.environ["TEMP"]) / "jb3" / "libro"
SALIDA = RAIZ / "libro_html"

if TEMPORAL.exists():
    shutil.rmtree(TEMPORAL)
shutil.copytree(FUENTE, TEMPORAL, ignore=shutil.ignore_patterns("_build"))

from jupyter_book.cli.main import main  # noqa: E402

sys.argv = ["jupyter-book", "build", str(TEMPORAL), "--builder", "html", "--all"]
try:
    main()
except SystemExit as salida:
    if salida.code not in (0, None):
        raise

if SALIDA.exists():
    shutil.rmtree(SALIDA)
shutil.copytree(TEMPORAL / "_build" / "html", SALIDA)
print("HTML en", SALIDA)
