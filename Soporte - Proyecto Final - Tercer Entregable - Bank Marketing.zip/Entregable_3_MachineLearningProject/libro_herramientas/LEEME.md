# Herramientas del Jupyter Book

El libro tiene dos partes: la Parte I interpreta cada resultado del dashboard (un capítulo por pestaña, con las mismas figuras y textos, porque importa `dashboard/src`) y la Parte II es el cuaderno `Proyecto Final - Tercer Entregable - Bank Marketing.ipynb` ejecutado y dividido por secciones.

| Archivo | Para qué sirve |
|---|---|
| `crear_libro.py` | Ensambla `libro/`: capítulos de la Parte I, cuaderno dividido, portada, configuración y tabla de contenido. |
| `capturas.py`, `lanzar_pestana.py` | Capturan las seis pestañas del dashboard local para ilustrar los capítulos. |
| `ejecutar_capitulos.py` | Ejecuta los capítulos de la Parte I con el kernel `bm_e3`. |
| `construir_html.py` | Construye el HTML con Jupyter Book 1 en una ruta corta y lo deja en `libro_html/`. |
| `construir_todo.ps1` | Ejecuta todo lo anterior en orden. |

Orden completo del proyecto: `scripts/ejecutar_experimentos.py` → `scripts/ejecutar_finales.py --computacional` → `scripts/construir_cuaderno.py --ejecutar` (el cuaderno exporta los resultados a `dashboard/datos/`) → `libro_herramientas/construir_todo.ps1`.
