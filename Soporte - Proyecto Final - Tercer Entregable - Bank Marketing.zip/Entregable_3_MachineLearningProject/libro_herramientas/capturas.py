"""Captura cada pestaña del dashboard local (Edge sin ventana) en libro/imagenes/.

Uso: python libro_herramientas/capturas.py
"""
import pathlib
import subprocess
import sys
import time
import urllib.request

import numpy as np
from PIL import Image

AQUI = pathlib.Path(__file__).resolve().parent
DESTINO = AQUI.parent / "libro" / "imagenes"
EDGE = r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"
PESTANAS = (("contexto", "pestana_1_contexto"), ("maestra", "pestana_2_maestra"),
            ("optimizacion", "pestana_3_optimizacion"), ("prueba", "pestana_4_prueba"),
            ("estadistica", "pestana_5_estadistica"), ("interpretabilidad", "pestana_6_interpretabilidad"))


def esperar(url, segundos=120):
    limite = time.time() + segundos
    while time.time() < limite:
        try:
            if urllib.request.urlopen(url, timeout=5).status == 200:
                return
        except Exception:  # noqa: BLE001
            time.sleep(2)
    raise TimeoutError(url)


def recortar(ruta):
    """Quita el fondo vacío que queda debajo del pie de página."""
    imagen = Image.open(ruta).convert("RGB")
    datos = np.asarray(imagen).astype(int)
    contraste = datos.max(axis=1) - datos.min(axis=1)
    filas = np.where(contraste.max(axis=1) > 12)[0]
    imagen.crop((0, 0, imagen.width, min(imagen.height, int(filas.max()) + 40))).save(ruta, optimize=True)


def main():
    DESTINO.mkdir(parents=True, exist_ok=True)
    for i, (pestana, nombre) in enumerate(PESTANAS):
        puerto = 8061 + i
        servidor = subprocess.Popen([sys.executable, str(AQUI / "lanzar_pestana.py"), pestana, str(puerto)],
                                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        try:
            esperar(f"http://127.0.0.1:{puerto}/")
            ruta = DESTINO / f"{nombre}.png"
            subprocess.run([EDGE, "--headless=new", "--disable-gpu", "--hide-scrollbars", f"--screenshot={ruta}",
                            "--window-size=1400,7000", "--virtual-time-budget=30000", f"http://127.0.0.1:{puerto}/"],
                           check=True, timeout=300)
            recortar(ruta)
            print(f"{nombre}.png -> {Image.open(ruta).size}")
        finally:
            servidor.terminate()
            servidor.wait(timeout=30)


if __name__ == "__main__":
    main()
