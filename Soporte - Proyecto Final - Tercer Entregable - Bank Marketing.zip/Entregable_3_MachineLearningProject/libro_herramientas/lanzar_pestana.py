"""Inicia el dashboard local con una pestaña activa (para capturarla). Uso: python lanzar_pestana.py <pestaña> <puerto>"""
import sys
import warnings
from pathlib import Path

warnings.filterwarnings("ignore")
sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "dashboard"))

from src.app import crear_app  # noqa: E402

pestana, puerto = sys.argv[1], int(sys.argv[2])
app = crear_app()
app.layout.children[1].value = pestana
app.run(host="127.0.0.1", port=puerto, debug=False)
