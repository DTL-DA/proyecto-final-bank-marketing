# Reconstruye el Jupyter Book del proyecto final: fuentes, capturas del dashboard, ejecución de la Parte I y HTML.
# Requiere: entorno conda bm_e3 (kernel "bm_e3"), Miniconda3\envs\ml_venv (Python 3.11) y .venvs\jb1 (Jupyter Book 1).
$aqui = $PSScriptRoot
$env:PYTHONIOENCODING = 'utf-8'
$env:PYTHONWARNINGS = 'ignore'
$py = "$HOME\miniconda3\envs\bm_e3\python.exe"

& $py "$aqui\crear_libro.py"          # 1. fuentes: Parte I (capítulos del dashboard) y Parte II (cuaderno dividido)
& $py "$aqui\capturas.py"             # 2. capturas de las seis pestañas del dashboard
& $py "$aqui\ejecutar_capitulos.py"   # 3. ejecuta los capítulos de la Parte I

$env:PYTHONPATH = "$HOME\.venvs\jb1\Lib\site-packages"
& "$HOME\Miniconda3\envs\ml_venv\python.exe" "$aqui\construir_html.py"   # 4. HTML en ..\libro_html
Remove-Item Env:PYTHONPATH
