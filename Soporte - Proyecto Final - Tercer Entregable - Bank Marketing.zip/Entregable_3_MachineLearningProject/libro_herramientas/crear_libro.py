"""Ensambla las fuentes del Jupyter Book del proyecto final (tercer entregable) en la carpeta `libro/`.

Parte I: un capítulo por pestaña del dashboard, con las mismas figuras y las mismas interpretaciones (importa los
módulos de `dashboard/src`), que luego se ejecutan con `ejecutar_capitulos.py`.
Parte II: el cuaderno ejecutado, dividido por secciones.

Uso: python libro_herramientas/crear_libro.py
"""
import copy
import pathlib
import re
import shutil
from textwrap import dedent

import nbformat as nbf

AQUI = pathlib.Path(__file__).resolve().parent
RAIZ = AQUI.parent
LIBRO = RAIZ / "libro"
CUADERNO = RAIZ / "Proyecto Final - Tercer Entregable - Bank Marketing.ipynb"
KERNEL = {"name": "bm_e3", "display_name": "Python (bm_e3 · Entregable 3)", "language": "python"}

NOMBRES_PARTE_II = {1: "01_base-de-datos", 2: "02_reserva-de-la-prueba", 3: "03_analisis-exploratorio",
                    4: "04_diseno-experimental", 5: "05_optimizacion-de-hiperparametros",
                    6: "06_optimizacion-computacional", 7: "07_evaluacion-de-modelos", 8: "08_comparacion-estadistica",
                    9: "09_conclusiones-y-limitaciones", 10: "10_referencias"}


def md(t):
    return nbf.v4.new_markdown_cell(dedent(t).strip("\n"))


def cod(t, etiqueta="remove-input"):
    c = nbf.v4.new_code_cell(dedent(t).strip("\n"))
    c.metadata["tags"] = [etiqueta]
    return c


PREPARACION = '''
import sys
sys.path.insert(0, "dashboard")
import pandas as pd
from IPython.display import HTML, Markdown, display
from src import figuras as fg
from src import textos as tx
from src.datos import num, objeto, pct, tabla

_primera = [True]


def figura(f):
    """Inserta la figura interactiva de Plotly (la librería se carga una vez por página)."""
    display(HTML(f.to_html(full_html=False, include_plotlyjs="cdn" if _primera[0] else False, config=fg.CONFIG,
                           default_width="100%")))
    _primera[0] = False


def texto(parrafos):
    display(Markdown("\\n\\n".join(parrafos)))


def tab(df, dec=3):
    display(df.style.format(precision=dec, decimal=",", thousands=" ", na_rep="—").hide(axis="index"))
'''

CAPITULOS = {
    "01_contexto": ("Pestaña 1 · Contexto y diseño experimental", "pestana_1_contexto", [
        ("md", "La primera pestaña presenta el problema, la partición cronológica y el diseño experimental: cuántas "
               "combinaciones se entrenan y cómo se valida cada una sin sesgo de selección."),
        ("md", "## 1.1 Cifras del proyecto y esquema de validación anidada"),
        ("code", "c = objeto('contexto')\ntab(pd.DataFrame({'Indicador': ['Llamadas tras eliminar duplicados', "
                 "'Entrenamiento', 'Prueba', 'Suscripción en entrenamiento', 'Suscripción en prueba', 'Combinaciones', "
                 "'Evaluaciones internas', 'Ajustes de modelos', 'Horas de CPU'], 'Valor': [num(c['registros_limpios']), "
                 "f\"{num(c['n_tr'])} ({c['desde_tr']} a {c['hasta_tr']})\", f\"{num(c['n_te'])} ({c['desde_te']} a "
                 "{c['hasta_te']})\", pct(c['prev_tr']), pct(c['prev_te']), str(c['combinaciones']), num(c['evaluaciones']), "
                 "num(c['ajustes']), num(c['horas_cpu'], 1)]}))"),
        ("code", "figura(fg.esquema_anidado())"),
        ("code", "tab(tabla('desglose'), dec=0)\ntab(tabla('esquema_anidado'), dec=1)"),
        ("code", "texto(tx.contexto())"),
    ]),
    "02_maestra": ("Pestaña 2 · Tabla maestra y balanceo", "pestana_2_maestra", [
        ("md", "La segunda pestaña reúne las 140 combinaciones evaluadas en el bucle externo, con filtros por tarea, "
               "modelo, balanceo y optimizador, y analiza el efecto de las técnicas de balanceo."),
        ("md", "## 2.1 Las mejores combinaciones"),
        ("code", "m = tabla('maestra')\nc_ = m[m['tarea'] == 'clf'].sort_values('auc_pr_media', ascending=False)\n"
                 "tab(c_[['Modelo', 'Balanceo', 'Optimizador', 'auc_pr_media', 'auc_pr_de', 'auc_media', 'recall_media', "
                 "'f1_media']].head(15).rename(columns={'auc_pr_media': 'AUC-PR media', 'auc_pr_de': 'AUC-PR DE', "
                 "'auc_media': 'AUC media', 'recall_media': 'Recall media', 'f1_media': 'F1 media'}), dec=4)\n"
                 "r_ = m[m['tarea'] == 'reg'].sort_values('rmse_media')\n"
                 "tab(r_[['Modelo', 'Optimizador', 'rmse_media', 'rmse_de', 'r2_media', 'rmse_seg_media']].head(10)"
                 ".rename(columns={'rmse_media': 'RMSE media', 'rmse_de': 'RMSE DE', 'r2_media': 'R² media', "
                 "'rmse_seg_media': 'RMSE (s) media'}), dec=4)"),
        ("md", "## 2.2 Desempeño por pliegue externo"),
        ("code", "tab(tabla('auc_por_pliegue'))\ntexto(tx.por_pliegue())"),
        ("md", "## 2.3 Mejor AUC-PR por modelo y balanceo"),
        ("code", "figura(fg.mapa_balanceo())\ntexto(tx.mapa_balanceo())"),
        ("md", "## 2.4 Efecto del balanceo"),
        ("code", "for m_ in ('recall', 'f1', 'auc_pr', 'brier'):\n    figura(fg.balanceo_barras(m_))"),
        ("code", "tab(tabla('balanceo_pruebas'), dec=4)\ntexto(tx.balanceo())"),
    ]),
    "03_optimizacion": ("Pestaña 3 · Optimización de hiperparámetros", "pestana_3_optimizacion", [
        ("md", "La tercera pestaña compara los métodos de optimización con el mismo presupuesto: la métrica del bucle "
               "externo, el costo, la convergencia (curvas *anytime*) y la eficiencia por unidad de presupuesto."),
        ("md", "## 3.1 Métrica externa, tiempo y evaluaciones por método"),
        ("code", "tab(tabla('opt_clf').rename(columns={'index': 'Método'}))\n"
                 "tab(tabla('opt_reg').rename(columns={'index': 'Método'}), dec=4)\ntexto(tx.optimizadores())"),
        ("md", "## 3.2 Curvas de desempeño en cualquier momento"),
        ("code", "for g_, e_ in (('clf', 'evaluaciones'), ('clf', 'tiempo'), ('reg', 'evaluaciones')):\n    figura(fg.anytime(g_, e_))"),
        ("code", "figura(fg.optuna_ejemplo())\nfigura(fg.params_optuna('Random Search'))\n"
                 "figura(fg.params_optuna('Bayesiana (Optuna TPE)'))"),
        ("md", "## 3.3 Eficiencia cuantitativa"),
        ("code", "tab(tabla('eficiencia').rename(columns={'optimizador': 'Método', 'tarea': 'Tarea'}))\n"
                 "tab(tabla('eficiencia_pruebas'), dec=4)\ntexto(tx.eficiencia())"),
        ("md", "## 3.4 Genético, multi-fidelidad y semillas"),
        ("code", "figura(fg.diversidad_genetico())\n"
                 "tab(tabla('halving'), dec=2)\ntab(tabla('semillas_optimizador').rename(columns={'index': 'Método'}), dec=4)"),
    ]),
    "04_prueba": ("Pestaña 4 · Evaluación en el conjunto de prueba", "pestana_4_prueba", [
        ("md", "La cuarta pestaña evalúa una sola vez en la prueba (2009-2010) el mejor representante de cada modelo, "
               "reajustado con todo el entrenamiento, junto con el modelo base del Entregable 2."),
        ("md", "## 4.1 Métricas, curvas y matrices de confusión"),
        ("code", "tab(tabla('finalistas_prueba').drop(columns=['clave', 'auc_inf', 'auc_sup', 'ap_inf', 'ap_sup']))\n"
                 "figura(fg.curvas_prueba('ROC'))\nfigura(fg.curvas_prueba('PR'))"),
        ("code", "for m_ in [m for m in fg.MODELOS + ['Referencia E2'] if m in set(tabla('curvas_prueba')['modelo'])]:\n"
                 "    figura(fg.matriz_confusion(m_))"),
        ("code", "texto(tx.prueba())"),
        ("md", "## 4.2 Calibración y recalibración"),
        ("code", "for m_ in tabla('calibracion_curvas')['modelo'].unique():\n    figura(fg.confiabilidad(m_))\n"
                 "tab(tabla('calibracion').drop(columns=['clave']), dec=4)\ntexto(tx.calibracion())"),
        ("md", "## 4.3 Regresión: duración de la llamada"),
        ("code", "tab(tabla('regresion_prueba').drop(columns=['clave']), dec=4)\nfigura(fg.serie_regresion())\n"
                 "figura(fg.residuos_regresion())\ntexto(tx.regresion())"),
    ]),
    "05_estadistica": ("Pestaña 5 · Comparación estadística", "pestana_5_estadistica", [
        ("md", "La quinta pestaña resume la secuencia jerárquica de pruebas: Friedman, Nemenyi y DeLong en "
               "clasificación; Model Confidence Set, Giacomini-White, Clark-West y Diebold-Mariano en regresión."),
        ("code", "tab(tabla('friedman_omnibus'))\nfigura(fg.rangos_cd('pliegues'))\nfigura(fg.rangos_cd('meses'))"),
        ("code", "tab(tabla('delong'), dec=4)\ntab(tabla('mcs'), dec=4)\ntab(tabla('pruebas_regresion'), dec=4)\n"
                 "tab(tabla('intervalos'), dec=4)\ntexto(tx.estadistica())"),
    ]),
    "06_interpretabilidad": ("Pestaña 6 · Interpretabilidad y costo computacional", "pestana_6_interpretabilidad", [
        ("md", "La sexta pestaña explica el mejor modelo con SHAP (global y local), lo contrasta con LIME en XGBoost y "
               "resume la optimización computacional: complejidad teórica frente a tiempos medidos."),
        ("md", "## 6.1 SHAP y LIME"),
        ("code", "figura(fg.shap_global())\nfigura(fg.shap_local('Bien clasificada'))\nfigura(fg.shap_local('Error elevado'))\n"
                 "tab(tabla('lime_shap'))\ntab(tabla('importancia_xgb'), dec=4)\ntexto(tx.interpretabilidad())"),
        ("md", "## 6.2 Costo computacional"),
        ("code", "tab(tabla('comp_complejidad'))\nfor n_, y_ in (('knn_escalamiento', 'Consulta (s)'), "
                 "('lineales_escalamiento', 'Ajuste (s)'), ('xgboost_escalamiento', 'Ajuste (s)'), "
                 "('svm_escalamiento', 'Ajuste (s)')):\n    figura(fg.escalamiento(n_, y_))\nfigura(fg.paralelizacion())\n"
                 "tab(tabla('comp_comparativa'), dec=4)\ntab(tabla('comp_perfil_componentes'), dec=2)\ntexto(tx.computacional())"),
    ]),
}


def escribir_parte_i():
    carpeta = LIBRO / "dashboard"
    carpeta.mkdir(parents=True, exist_ok=True)
    for nombre, (titulo, imagen, bloques) in CAPITULOS.items():
        nb = nbf.v4.new_notebook()
        nb.metadata["kernelspec"] = dict(KERNEL)
        nb.cells.append(md(f"# {titulo}"))
        nb.cells.append(cod(PREPARACION, "remove-cell"))
        nb.cells.append(md(bloques[0][1] + f"\n\n![Vista de la pestaña en el dashboard](../imagenes/{imagen}.png)\n\n"
                           "Las figuras son interactivas (se puede pasar el cursor sobre ellas) y las interpretaciones "
                           "usan las mismas cifras que el dashboard y que el cuaderno."))
        for tipo, contenido in bloques[1:]:
            nb.cells.append(md(contenido) if tipo == "md" else cod(contenido))
        nbf.write(nb, carpeta / f"{nombre}.ipynb")
        print(f"  dashboard/{nombre}.ipynb")


def subir_encabezados(texto: str) -> str:
    """Sube un nivel cada encabezado (## -> #), sin tocar los bloques de código."""
    salida, en_bloque = [], False
    for linea in texto.split("\n"):
        if linea.lstrip().startswith("```"):
            en_bloque = not en_bloque
        elif not en_bloque:
            linea = re.sub(r"^(#{2,6}) ", lambda m: m.group(1)[1:] + " ", linea)
        salida.append(linea)
    return "\n".join(salida)


def dividir_cuaderno():
    cuaderno = nbf.read(CUADERNO, as_version=4)

    def inicio_seccion(c):
        fuente = c.source
        if c.cell_type == "code" and c.get("outputs"):
            fuente = "".join(o.get("data", {}).get("text/markdown", "") for o in c.outputs if "data" in o)
        return re.match(r"^## (\d+)\. ", fuente) if c.cell_type in ("markdown", "code") else None

    inicios = [i for i, c in enumerate(cuaderno.cells) if inicio_seccion(c)]
    limites = [0] + inicios + [len(cuaderno.cells)]
    carpeta = LIBRO / "desarrollo"
    carpeta.mkdir(parents=True, exist_ok=True)
    for k in range(len(limites) - 1):
        celdas = [copy.deepcopy(c) for c in cuaderno.cells[limites[k]:limites[k + 1]]]
        if k == 0:
            nombre = "00_introduccion"
            celdas[0].source = re.sub(r"^# .*", "# Introducción", celdas[0].source, count=1)
        else:
            numero = int(inicio_seccion(celdas[0]).group(1))
            nombre = NOMBRES_PARTE_II[numero]
            for c in celdas:
                if c.cell_type == "markdown":
                    c.source = subir_encabezados(c.source)
                elif c.cell_type == "code":
                    for o in c.get("outputs", []):
                        if "data" in o and "text/markdown" in o["data"]:
                            o["data"]["text/markdown"] = subir_encabezados(o["data"]["text/markdown"])
            if celdas[0].cell_type == "code":
                # El encabezado lo genera el código: se pasa a una celda Markdown para que Sphinx titule el capítulo
                salida = next(o for o in celdas[0].outputs if "data" in o and "text/markdown" in o["data"])
                titulo, _, resto = salida["data"]["text/markdown"].partition("\n")
                salida["data"]["text/markdown"] = resto.lstrip("\n")
                celdas[0].metadata["tags"] = ["remove-input"]
                celdas.insert(0, nbf.v4.new_markdown_cell(titulo))
        capitulo = nbf.v4.new_notebook(cells=celdas)
        capitulo.metadata = copy.deepcopy(cuaderno.metadata)
        nbf.write(capitulo, carpeta / f"{nombre}.ipynb")
        print(f"  desarrollo/{nombre}.ipynb ({len(celdas)} celdas)")


PORTADA = r'''# Proyecto final · Tercer entregable: Bank Marketing

```{image} imagenes/portada.jpg
:alt: Portada del proyecto final, tercer entregable: Bank Marketing
:width: 100%
```

**Modelos de Machine Learning para clasificación y regresión con optimización de hiperparámetros, optimización computacional y validación estadística**

- **Autor:** Donny Torres
- **Programa:** Maestría en Analítica de Datos, Universidad del Norte (Barranquilla)
- **Asignatura:** Machine Learning
- **Fecha:** octubre de 2026
- **Conjunto de datos:** *Bank Marketing* con contexto social y económico (`bank-additional-full.csv`), UCI Machine Learning Repository: <https://archive.ics.uci.edu/dataset/222/bank+marketing> (licencia CC BY 4.0)
- **Dashboard predictivo en línea:** <https://proyecto-final-bank-marketing.onrender.com> (páginas Contexto, EDA y Modelos, con predicción en vivo y su explicación SHAP; está en el plan gratuito de Render, así que la primera carga tras 15 minutos sin visitas tarda cerca de un minuto y medio)

## Contenido

El proyecto predice, con información disponible antes de la llamada, si un cliente contactado por el telemercadeo de un banco portugués suscribirá un depósito a término, y explora como rama de regresión la duración de la llamada. Sobre el modelo base del Entregable 2 se construye el *pipeline* combinatorio que pide la guía: 7 modelos × 4 técnicas de balanceo × 4 métodos de optimización en clasificación (112), 7 modelos × 4 métodos en regresión (28): **140 combinaciones** evaluadas con validación cruzada anidada y cronológica.

**Parte I. El dashboard y la interpretación de sus resultados.** Un capítulo por cada una de las seis pestañas del dashboard de análisis, con sus mismas figuras interactivas y una interpretación de cada resultado:

1. **Contexto y diseño experimental:** partición, explosión combinatoria y validación anidada.
2. **Tabla maestra y balanceo:** las 140 combinaciones y el efecto de SMOTE, ADASYN y `class_weight`.
3. **Optimización de hiperparámetros:** Grid, Random, Bayesiana, Genética y Successive Halving; curvas *anytime* y eficiencia.
4. **Evaluación en prueba:** métricas con intervalos, curvas ROC y PR, matrices de confusión, calibración y regresión.
5. **Comparación estadística:** Friedman, Nemenyi, DeLong, Model Confidence Set, Giacomini-White, Clark-West y Diebold-Mariano.
6. **Interpretabilidad y costo computacional:** SHAP, LIME, complejidad teórica, escalamiento, paralelización y perfilamiento.

**Parte II. Desarrollo completo.** El cuaderno ejecutado, dividido por secciones, con el código, las tablas, las figuras y todas las interpretaciones, incluido lo que el dashboard no muestra (auditoría de calidad, EDA completo, justificación de cada método y de cada espacio de búsqueda, diagnóstico de residuos y conclusiones).

## Cómo leer las interpretaciones

Cada interpretación tiene tres párrafos: primero lo que muestra el resultado, con las cifras reales; luego lo que significa para el problema o el modelo; y al final la decisión que se toma. Las cifras se calculan en la misma ejecución que genera el texto, y el dashboard de análisis, la Parte I y la Parte II leen los mismos resultados, de modo que coinciden.

## Reproducibilidad

La partición es cronológica y, por tanto, determinista; todos los procedimientos aleatorios usan la semilla global `SEED = 42`. Las versiones de las librerías están en `requirements.txt` y cada una de las 140 combinaciones está registrada en la tabla maestra (`resultados/tabla_maestra.csv`) con sus hiperparámetros por pliegue, métricas, tiempos y semilla.
'''

CONFIG = '''title: "Proyecto final · Bank Marketing"
author: Donny Torres · Maestría en Analítica de Datos, Universidad del Norte
copyright: "2026"
only_build_toc_files: true

execute:
  execute_notebooks: "off"

parse:
  myst_enable_extensions:
    - dollarmath
    - amsmath
    - colon_fence
    - html_image

sphinx:
  config:
    language: es
    nb_merge_streams: true
    html_theme_options:
      show_toc_level: 2
      use_download_button: true
      use_fullscreen_button: true
      home_page_in_toc: true
'''

TOC = '''format: jb-book
root: portada
parts:
  - caption: Parte I · El dashboard y la interpretación de sus resultados
    chapters:
''' + "".join(f"      - file: dashboard/{n}\n" for n in CAPITULOS) + '''  - caption: Parte II · Desarrollo completo
    chapters:
      - file: desarrollo/00_introduccion
''' + "".join(f"      - file: desarrollo/{n}\n" for n in NOMBRES_PARTE_II.values())


def main():
    imagenes = None
    if (LIBRO / "imagenes").exists():
        imagenes = {p.name: p.read_bytes() for p in (LIBRO / "imagenes").glob("*.png")}
    if LIBRO.exists():
        shutil.rmtree(LIBRO)
    (LIBRO / "imagenes").mkdir(parents=True)
    for nombre, datos in (imagenes or {}).items():
        (LIBRO / "imagenes" / nombre).write_bytes(datos)
    shutil.copyfile(RAIZ / "Image Bank Marketing _2a828976.jpg", LIBRO / "imagenes" / "portada.jpg")
    print("Parte I (capítulos del dashboard):")
    escribir_parte_i()
    print("Parte II (cuaderno dividido):")
    dividir_cuaderno()
    (LIBRO / "portada.md").write_text(PORTADA, encoding="utf-8")
    (LIBRO / "_config.yml").write_text(CONFIG, encoding="utf-8")
    (LIBRO / "_toc.yml").write_text(TOC, encoding="utf-8")
    print("Listo:", LIBRO)


if __name__ == "__main__":
    main()
