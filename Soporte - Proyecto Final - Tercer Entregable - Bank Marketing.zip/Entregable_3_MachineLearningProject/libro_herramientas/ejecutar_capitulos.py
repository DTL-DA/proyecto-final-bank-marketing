"""Ejecuta los capítulos de la Parte I con el kernel `bm_e3`, desde la raíz del proyecto, y guarda sus salidas.

Uso: python libro_herramientas/ejecutar_capitulos.py
"""
import pathlib
import time

import nbformat
from nbclient import NotebookClient

RAIZ = pathlib.Path(__file__).resolve().parent.parent

for destino in sorted((RAIZ / "libro" / "dashboard").glob("*.ipynb")):
    cuaderno = nbformat.read(destino, as_version=4)
    inicio = time.time()
    NotebookClient(cuaderno, kernel_name="bm_e3", timeout=1800, resources={"metadata": {"path": str(RAIZ)}}).execute()
    nbformat.write(cuaderno, destino)
    print(f"ejecutado: {destino.name} ({time.time() - inicio:.0f} s)")
